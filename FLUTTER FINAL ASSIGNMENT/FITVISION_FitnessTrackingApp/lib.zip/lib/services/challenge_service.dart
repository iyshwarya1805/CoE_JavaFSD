// import 'package:flutter/material.dart';
// import '../models/challenge_model.dart';
// import '../models/reward_model.dart';

// class ChallengeService extends ChangeNotifier {
//   List<Challenge> _challenges = [];
//   List<Reward> _rewards = [];
//   int _userPoints = 0;

//   List<Challenge> get challenges => _challenges;
//   List<Challenge> get activeChallenges => 
//       _challenges.where((challenge) => !challenge.isCompleted).toList();
//   List<Challenge> get completedChallenges => 
//       _challenges.where((challenge) => challenge.isCompleted).toList();
//   List<Reward> get rewards => _rewards;
//   int get userPoints => _userPoints;

//   ChallengeService() {
//     _initializeData();
//   }

//   void _initializeData() {
//     // Sample challenges
//     _challenges = [
//       Challenge(
//         id: '1',
//         title: '10K Steps Challenge',
//         description: 'Complete 10,000 steps in a single day',
//         targetValue: 10000,
//         metric: 'steps',
//         points: 50,
//         startDate: DateTime.now(),
//         endDate: DateTime.now().add(const Duration(days: 7)),
//         currentProgress: 4500,
//       ),
//       Challenge(
//         id: '2',
//         title: 'Weekly Workout Warrior',
//         description: 'Complete 5 workouts this week',
//         targetValue: 5,
//         metric: 'workouts',
//         points: 100,
//         startDate: DateTime.now(),
//         endDate: DateTime.now().add(const Duration(days: 7)),
//         currentProgress: 2,
//       ),
//       Challenge(
//         id: '3',
//         title: 'Calorie Crusher',
//         description: 'Burn 5,000 calories in a week',
//         targetValue: 5000,
//         metric: 'calories',
//         points: 75,
//         startDate: DateTime.now(),
//         endDate: DateTime.now().add(const Duration(days: 7)),
//         currentProgress: 1200,
//       ),
//     ];

//     // Sample rewards
//     _rewards = [
//       Reward(
//         id: '1',
//         title: 'Premium Workout Plan',
//         description: 'Unlock a premium workout plan of your choice',
//         pointsCost: 200,
//         iconPath: 'assets/icons/premium_workout.png',
//       ),
//       Reward(
//         id: '2',
//         title: 'Dark Mode Theme',
//         description: 'Unlock the dark mode theme for the app',
//         pointsCost: 100,
//         iconPath: 'assets/icons/dark_mode.png',
//       ),
//       Reward(
//         id: '3',
//         title: 'Fitness Badge',
//         description: 'Exclusive profile badge for your accomplishment',
//         pointsCost: 50,
//         iconPath: 'assets/icons/badge.png',
//       ),
//     ];

//     // Sample user points
//     _userPoints = 125;
//   }

//   void updateChallengeProgress(String challengeId, int newProgress) {
//     final index = _challenges.indexWhere((c) => c.id == challengeId);
//     if (index != -1) {
//       final challenge = _challenges[index];
//       challenge.currentProgress = newProgress;
      
//       // Check if challenge is completed
//       if (!challenge.isCompleted && challenge.currentProgress >= challenge.targetValue) {
//         challenge.isCompleted = true;
//         _userPoints += challenge.points;
//       }
      
//       notifyListeners();
//     }
//   }

//   bool redeemReward(String rewardId) {
//     final reward = _rewards.firstWhere((r) => r.id == rewardId);
//     if (_userPoints >= reward.pointsCost && !reward.isRedeemed) {
//       reward.isRedeemed = true;
//       _userPoints -= reward.pointsCost;
//       notifyListeners();
//       return true;
//     }
//     return false;
//   }
// }
